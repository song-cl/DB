create definer = root@localhost view depview as
select `human_management`.`department`.`dep_no`   AS `dep_no`,
       `human_management`.`department`.`dep_name` AS `dep_name`,
       count(`human_management`.`staff`.`dep_no`) AS `部门人数`
from (`human_management`.`department`
         join `human_management`.`staff`
              on ((`human_management`.`staff`.`dep_no` = `human_management`.`department`.`dep_no`)))
group by `human_management`.`department`.`dep_no`, `human_management`.`department`.`dep_name`;

