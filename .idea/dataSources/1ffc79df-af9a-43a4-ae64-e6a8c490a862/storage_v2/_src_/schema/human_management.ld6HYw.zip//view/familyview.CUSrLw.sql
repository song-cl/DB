create definer = root@localhost view familyview as
select `human_management`.`family_relations`.`f_no`        AS `f_no`,
       `human_management`.`family_relations`.`s_no`        AS `s_no`,
       `human_management`.`family_relations`.`f_name`      AS `f_name`,
       `human_management`.`family_relations`.`f_relation`  AS `f_relation`,
       `human_management`.`family_relations`.`f_age`       AS `f_age`,
       `human_management`.`family_relations`.`f_job`       AS `f_job`,
       `human_management`.`family_relations`.`f_work_unit` AS `f_work_unit`
from (`human_management`.`family_relations`
         join `human_management`.`staff`
              on ((`human_management`.`family_relations`.`s_no` = `human_management`.`staff`.`s_no`)));

