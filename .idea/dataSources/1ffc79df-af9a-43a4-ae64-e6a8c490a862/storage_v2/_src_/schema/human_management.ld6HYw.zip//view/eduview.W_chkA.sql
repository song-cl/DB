create definer = root@localhost view eduview as
select `human_management`.`education`.`edu_no`           AS `edu_no`,
       `human_management`.`education`.`degree`           AS `degree`,
       `human_management`.`education`.`major`            AS `major`,
       `human_management`.`education`.`graduate_collage` AS `graduate_collage`,
       `human_management`.`education`.`graduate_date`    AS `graduate_date`,
       `human_management`.`staff`.`s_name`               AS `s_name`
from (`human_management`.`education`
         join `human_management`.`staff`
              on ((`human_management`.`education`.`s_no` = `human_management`.`staff`.`s_no`)));

