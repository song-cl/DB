create definer = root@localhost view workview as
select `human_management`.`work_experience`.`work_no`           AS `work_no`,
       `human_management`.`work_experience`.`work_company`      AS `work_company`,
       `human_management`.`work_experience`.`work_department`   AS `work_department`,
       `human_management`.`work_experience`.`work_position`     AS `work_position`,
       `human_management`.`work_experience`.`work_date`         AS `work_date`,
       `human_management`.`work_experience`.`transition_date`   AS `transition_date`,
       `human_management`.`work_experience`.`transition_reason` AS `transition_reason`,
       `human_management`.`staff`.`s_name`                      AS `s_name`
from (`human_management`.`work_experience`
         join `human_management`.`staff`
              on ((`human_management`.`work_experience`.`s_no` = `human_management`.`staff`.`s_no`)));

