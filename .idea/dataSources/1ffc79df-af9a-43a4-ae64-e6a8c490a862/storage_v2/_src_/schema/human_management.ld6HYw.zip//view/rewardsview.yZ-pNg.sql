create definer = root@localhost view rewardsview as
select `human_management`.`rewards`.`r_no`     AS `r_no`,
       `human_management`.`staff`.`s_name`     AS `s_name`,
       `human_management`.`rewards`.`r_reason` AS `r_reason`,
       `human_management`.`rewards`.`r_date`   AS `r_date`,
       `human_management`.`rewards`.`r_money`  AS `r_money`
from (`human_management`.`rewards`
         join `human_management`.`staff`
              on ((`human_management`.`rewards`.`s_no` = `human_management`.`staff`.`s_no`)));

