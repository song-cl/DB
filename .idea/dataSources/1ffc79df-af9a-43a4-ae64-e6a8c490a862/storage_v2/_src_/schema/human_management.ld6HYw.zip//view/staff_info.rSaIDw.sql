create definer = root@localhost view staff_info as
select `human_management`.`staff`.`s_no`     AS `s_no`,
       `human_management`.`staff`.`s_name`   AS `s_name`,
       `human_management`.`staff`.`s_sex`    AS `s_sex`,
       `human_management`.`staff`.`s_birth`  AS `s_birth`,
       `human_management`.`staff`.`s_id`     AS `s_id`,
       `human_management`.`staff`.`s_tel`    AS `s_tel`,
       `human_management`.`staff`.`s_degree` AS `s_degree`
from `human_management`.`staff`;

